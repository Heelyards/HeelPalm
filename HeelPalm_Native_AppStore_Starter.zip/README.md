# HeelPalm Native (SwiftUI) • App Store starter

This is an **actual native SwiftUI iOS source project**, not a signed `.ipa`. It has **not** been compiled or tested in Xcode in this environment. The GitHub Actions workflow tests the unsigned simulator build remotely using macOS. Follow the build check and resolve any compiler warnings/errors before signing.

## What works in source

- Personal / Work / Heelyards to-do lists, due dates, completion and deletion
- Memos stored locally
- Apple EventKit calendar viewing with read-only calendar selection (work calendar visibility depends on iOS and company restrictions)
- Speech-to-text request capture, manual review, native printing
- Exact white/silver ram logo on blue supplied by the user
- **Web → Native task/memo migration**: import JSON exported from HeelPalm web app (More → Export backup). Import replaces local native data after confirmation. Calendar/event copies do not migrate. Keep the original web backup!

## Build with no Mac (two stages)

### A. Free/unsigned compile test in cloud

1. Create your own **private GitHub repository**. Do not put actual calendar data or backup files in the repository.
2. Upload the **contents** of this project to the repository root. `project.yml`, `HeelPalm/` and `.github/` must be at the root. On Windows, extracting this ZIP before uploading is easiest.
3. In GitHub, open **Actions → HeelPalm iOS build check → Run workflow**. It starts a macOS runner, runs XcodeGen, and compiles an unsigned iOS Simulator app. Check the logs. GitHub Actions usage limits/billing may apply.
4. This does **not** produce an iPhone-installable app. It checks compilation only.

### B. Signed iPhone/TestFlight build in hosted macOS

1. When you're ready, enroll in the **Apple Developer Program** ($99/year US) and create the app identifier `com.heelyards.heelpalm` (or change it to another unique identifier in `project.yml`). Choose individual or organization enrollment as appropriate.
2. Configure a hosted macOS service such as Codemagic to connect to your private source repository. It must generate the Xcode project (`brew install xcodegen` then `xcodegen generate`) and run an iOS archive with **your Apple signing credentials** using the provider's secure signing mechanism. Never put passwords, private signing keys, or `.p12` files into your repository.
3. Upload the signed archive/IPA through App Store Connect/TestFlight. After Apple processing, install via TestFlight on your iPhone. Test calendar authorization, home/work calendars, migration, voice and printing on an actual device.
4. App Store release requires privacy disclosures, screenshots, a support URL, privacy policy, and App Review. TestFlight is not the same as App Store approval.

**Important:** GitHub's unsigned simulator workflow isn't a replacement for code signing or TestFlight. There is no approved direct route to side-load an unsigned iOS application from these files.

## Calendar/privacy design

Calendar data stays on device and is fetched through Apple's EventKit. Work Microsoft 365 calendars already in Apple Calendar may be visible, but employer security controls may restrict access. App asks for full EventKit read permission because Apple's API requires it to read details. The code does not write to calendar events. Microphone/speech permissions are separate. There is no ChatGPT or Microsoft sign-in in this native build.

## Roadmap before public App Store release

- Move task/memo storage from UserDefaults to SwiftData or structured file storage; add native export/backup
- Set up cloud sync with explicit user consent if desired
- Notifications, richer recurring tasks, accessibility and quality assurance
- Audit for private data, test on physical iPhones and obtain real-world feedback
- Confirm product branding rights and complete App Store privacy disclosures

## Local build on a Mac (optional, not needed for cloud workflow)

`brew install xcodegen && xcodegen generate`, then open `HeelPalm.xcodeproj` in Xcode. Set the signing team in Signing & Capabilities.
