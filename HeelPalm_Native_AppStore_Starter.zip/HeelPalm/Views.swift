import SwiftUI
import UIKit
import UniformTypeIdentifiers

private let blue = Color(red: 0.14, green: 0.62, blue: 0.90)

struct HPMainView: View {
    @EnvironmentObject var store: HPStore
    @EnvironmentObject var calendars: HPCalendarManager
    @State private var selectedDate = Date()
    @State private var showCapture = false
    @State private var tab = 0

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        HPMasthead()
                        HPDateStrip(selectedDate: $selectedDate)
                        HPTodayAgenda(date: selectedDate)
                        HPTaskSection(date: selectedDate)
                    }
                    .padding()
                }
                .background(Color(uiColor: .systemGroupedBackground))
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button { showCapture = true } label: { Image(systemName: "plus.circle.fill").font(.title2) }
                    }
                    ToolbarItem(placement: .topBarLeading) {
                        Button { HPPrinter.printDay(selectedDate, events: calendars.events(on: selectedDate), tasks: store.tasks) } label: { Image(systemName: "printer") }
                            .accessibilityLabel("Print daily agenda")
                    }
                }
            }
            .tabItem { Label("Today", systemImage: "calendar") }.tag(0)

            NavigationStack { HPAllTasksView() }
                .tabItem { Label("To-Dos", systemImage: "checklist") }.tag(1)

            NavigationStack { HPMemosView() }
                .tabItem { Label("Memos", systemImage: "note.text") }.tag(2)

            NavigationStack { HPSettingsView() }
                .tabItem { Label("Calendars", systemImage: "calendar.badge.clock") }.tag(3)
        }
        .sheet(isPresented: $showCapture) { HPQuickCapture() }
    }
}

private struct HPMasthead: View {
    var body: some View {
        HStack(spacing: 12) {
            Image("RamBadge")
                .resizable().scaledToFill().frame(width: 54, height: 54).clipShape(RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 1) {
                Text("HeelPalm").font(.system(size: 29, weight: .bold, design: .rounded))
                Text("Your day. In your pocket.").font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }
}

private struct HPDateStrip: View {
    @Binding var selectedDate: Date
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(selectedDate.formatted(.dateTime.weekday(.wide).month(.wide).day()))
                    .font(.headline)
                Spacer()
                Button("Today") { selectedDate = Date() }.font(.subheadline)
            }
            HStack(spacing: 4) {
                ForEach(-3...3, id: \.self) { offset in
                    let date = Calendar.current.date(byAdding: .day, value: offset, to: Date()) ?? Date()
                    Button {
                        selectedDate = date
                    } label: {
                        VStack(spacing: 7) {
                            Text(date.formatted(.dateTime.weekday(.abbreviated))).font(.caption2)
                            Text(date.formatted(.dateTime.day())).font(.headline)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Calendar.current.isDate(date, inSameDayAs: selectedDate) ? blue : Color(uiColor: .secondarySystemGroupedBackground))
                        .foregroundStyle(Calendar.current.isDate(date, inSameDayAs: selectedDate) ? .white : .primary)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }.buttonStyle(.plain)
                }
            }
            DatePicker("Jump to date", selection: $selectedDate, displayedComponents: .date)
                .datePickerStyle(.compact).font(.caption)
        }
    }
}

private struct HPTodayAgenda: View {
    @EnvironmentObject var calendars: HPCalendarManager
    let date: Date
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Appointments", systemImage: "calendar").font(.title3.bold())
            if !calendars.authorized {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Bring your Apple, PetSafe, and Heelyards calendars into one view.").font(.subheadline)
                    Button("Connect iPhone Calendars") { Task { await calendars.requestAccess() } }.buttonStyle(.borderedProminent)
                }.hpCard()
            } else if calendars.events(on: date).isEmpty {
                Text("No appointments on this date.").foregroundStyle(.secondary).hpCard()
            } else {
                ForEach(calendars.events(on: date)) { event in
                    HStack(alignment: .top, spacing: 10) {
                        RoundedRectangle(cornerRadius: 4).fill(Color(hex: event.colorHex)).frame(width: 5)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(event.title).font(.subheadline.bold())
                            Text(event.allDay ? "All day" : "\(event.start.formatted(date: .omitted, time: .shortened)) – \(event.end.formatted(date: .omitted, time: .shortened))")
                                .font(.caption).foregroundStyle(.secondary)
                            Text("\(event.calendar) · \(event.source)").font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                    }.frame(minHeight: 50).hpCard()
                }
            }
        }
    }
}

private struct HPTaskSection: View {
    @EnvironmentObject var store: HPStore
    let date: Date
    private var tasks: [HPTask] {
        store.tasks.filter { !$0.done && ($0.due == nil || Calendar.current.startOfDay(for: $0.due!) <= Calendar.current.startOfDay(for: date)) }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("To-Do", systemImage: "checkmark.square").font(.title3.bold())
            if tasks.isEmpty { Text("Nothing due. Enjoy the breathing room.").foregroundStyle(.secondary).hpCard() }
            else {
                ForEach(tasks) { task in
                    HStack(spacing: 12) {
                        Button { store.toggle(task) } label: { Image(systemName: "circle").font(.title3) }
                        VStack(alignment: .leading, spacing: 3) {
                            Text(task.title).font(.subheadline)
                            Text(task.bucket.rawValue).font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                    }.hpCard()
                }
            }
        }
    }
}

private struct HPAllTasksView: View {
    @EnvironmentObject var store: HPStore
    @State private var bucket: HPBucket? = nil
    @State private var showCapture = false
    private var filtered: [HPTask] { store.tasks.filter { bucket == nil || $0.bucket == bucket } }
    var body: some View {
        List {
            Picker("List", selection: $bucket) {
                Text("All").tag(HPBucket?.none)
                ForEach(HPBucket.allCases) { item in Text(item.rawValue).tag(Optional(item)) }
            }.pickerStyle(.segmented)
            ForEach(filtered) { task in
                HStack {
                    Button { store.toggle(task) } label: {
                        Image(systemName: task.done ? "checkmark.circle.fill" : "circle")
                    }.buttonStyle(.plain)
                    VStack(alignment: .leading) {
                        Text(task.title).strikethrough(task.done).foregroundStyle(task.done ? .secondary : .primary)
                        Text("\(task.bucket.rawValue)\(task.due.map { " · " + $0.formatted(date: .abbreviated, time: .omitted) } ?? "")")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                .swipeActions { Button("Delete", role: .destructive) { store.delete(task) } }
            }
        }
        .navigationTitle("To-Dos")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { HPPrinter.printTasks(filtered) } label: { Image(systemName: "printer") }
                Button { showCapture = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $showCapture) { HPQuickCapture(initialMode: .task) }
    }
}

private struct HPMemosView: View {
    @EnvironmentObject var store: HPStore
    @State private var showCapture = false
    var body: some View {
        List {
            ForEach(store.memos) { memo in
                VStack(alignment: .leading, spacing: 6) {
                    Text(memo.title).font(.headline)
                    Text(memo.body).font(.subheadline).foregroundStyle(.secondary)
                    Text(memo.created.formatted(date: .abbreviated, time: .omitted)).font(.caption2).foregroundStyle(.tertiary)
                }.padding(.vertical, 4)
                .swipeActions { Button("Delete", role: .destructive) { store.deleteMemo(memo) } }
            }
        }
        .navigationTitle("Memos")
        .toolbar { Button { showCapture = true } label: { Image(systemName: "plus") } }
        .sheet(isPresented: $showCapture) { HPQuickCapture(initialMode: .memo) }
    }
}

private struct HPSettingsView: View {
    @EnvironmentObject var calendars: HPCalendarManager
    @EnvironmentObject var store: HPStore
    @State private var showImporter = false
    @State private var pendingImport: HPWebImport? = nil
    @State private var showImportConfirmation = false
    @State private var importMessage: String? = nil
    var body: some View {
        List {
            Section("Apple Calendar") {
                Text(calendars.authorized ? "Connected to calendars available on this iPhone" : "Not connected")
                    .foregroundStyle(.secondary)
                if !calendars.authorized {
                    Button("Grant Calendar Access") { Task { await calendars.requestAccess() } }
                } else {
                    Button("Refresh Calendar") { calendars.reload() }
                }
                if let message = calendars.message { Text(message).font(.caption).foregroundStyle(.red) }
            }
            if calendars.authorized {
                Section("Visible calendars") {
                    ForEach(calendars.availableCalendars, id: \.id) { cal in
                        Button { calendars.toggleCalendar(cal.id) } label: {
                            HStack {
                                Image(systemName: calendars.enabledCalendarIDs.contains(cal.id) ? "checkmark.circle.fill" : "circle")
                                VStack(alignment: .leading) {
                                    Text(cal.title).foregroundStyle(.primary)
                                    Text(cal.source).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }
            }
            Section("Bring over your HeelPalm tasks") {
                Button("Import web app backup (.json)") { showImporter = true }
                Text("In the existing Safari HeelPalm, choose More → Export backup. Import that JSON file here to transfer tasks and memos. It replaces native tasks and memos after confirmation.")
                    .font(.caption).foregroundStyle(.secondary)
                if let importMessage { Text(importMessage).font(.caption) }
            }
            Section("Privacy") {
                Text("Calendar appointments are read from iOS EventKit. HeelPalm does not edit external appointments or upload them to a HeelPalm server.")
                Text("Tasks and memos are saved locally on this iPhone. Export your existing web backup before moving into this app. Native cloud backup/sync is not yet implemented.")
            }
        }
        .navigationTitle("Calendars")
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json]) { result in
            switch result {
            case .success(let url):
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                do {
                    let data = try Data(contentsOf: url)
                    pendingImport = try HPWebImport.read(data)
                    showImportConfirmation = true
                } catch { importMessage = "Import failed: \(error.localizedDescription)" }
            case .failure(let error): importMessage = "Could not open file: \(error.localizedDescription)"
            }
        }
        .confirmationDialog("Replace local native tasks and memos?", isPresented: $showImportConfirmation) {
            Button("Replace with web backup", role: .destructive) {
                guard let imported = pendingImport else { return }
                store.restore(imported)
                importMessage = "Imported \(imported.tasks.count) tasks and \(imported.memos.count) memos; skipped \(imported.skipped) other entries."
                pendingImport = nil
            }
            Button("Cancel", role: .cancel) { pendingImport = nil }
        } message: {
            Text("This replaces current native tasks/memos. Calendar snapshots are skipped because the native app reads device calendars directly.")
        }
    }
}

private struct HPQuickCapture: View {
    enum Mode: String, CaseIterable { case task = "Task", memo = "Memo" }
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: HPStore
    @StateObject private var speech = HPSpeechCapture()
    @State private var mode: Mode
    @State private var text = ""
    @State private var notes = ""
    @State private var bucket: HPBucket = .personal
    @State private var withDueDate = false
    @State private var dueDate = Date()

    init(initialMode: Mode = .task) { _mode = State(initialValue: initialMode) }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Save as", selection: $mode) {
                        ForEach(Mode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }.pickerStyle(.segmented)
                    TextField(mode == .task ? "What needs doing?" : "Memo title", text: $text, axis: .vertical)
                        .lineLimit(2...4)
                    if mode == .memo { TextField("Details", text: $notes, axis: .vertical).lineLimit(3...8) }
                }
                Section("Speak or dictate") {
                    Button {
                        if speech.listening { speech.stop(); text = speech.transcript }
                        else { Task { await speech.start() } }
                    } label: {
                        Label(speech.listening ? "Stop & use transcript" : "Record speech", systemImage: speech.listening ? "stop.circle.fill" : "mic.circle.fill")
                    }
                    if speech.listening { Text(speech.transcript.isEmpty ? "Listening…" : speech.transcript).font(.subheadline) }
                    if let error = speech.errorMessage { Text(error).font(.caption).foregroundStyle(.red) }
                    Text("Or tap the microphone on your iPhone keyboard. Review the text before saving.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                if mode == .task {
                    Section("Organize") {
                        Picker("List", selection: $bucket) { ForEach(HPBucket.allCases) { Text($0.rawValue).tag($0) } }
                        Toggle("Add due date", isOn: $withDueDate)
                        if withDueDate { DatePicker("Due", selection: $dueDate, displayedComponents: .date) }
                    }
                }
            }
            .navigationTitle("Quick Capture")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { speech.stop(); dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        let finalText = text.isEmpty ? speech.transcript : text
                        speech.stop()
                        if mode == .task { store.addTask(finalText, due: withDueDate ? dueDate : nil, bucket: bucket) }
                        else { store.addMemo(finalText, body: notes) }
                        dismiss()
                    }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && speech.transcript.isEmpty)
                }
            }
            .onDisappear { speech.stop() }
        }
    }
}

private extension View {
    func hpCard() -> some View {
        self.frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 13))
    }
}

private extension Color {
    init(hex: String) {
        let h = hex.replacingOccurrences(of: "#", with: "")
        let n = Int(h, radix: 16) ?? 0x3486D3
        self.init(.sRGB, red: Double((n >> 16) & 255) / 255, green: Double((n >> 8) & 255) / 255, blue: Double(n & 255) / 255, opacity: 1)
    }
}
