import Foundation

enum HPBucket: String, CaseIterable, Codable, Identifiable {
    case personal = "Personal", work = "Work", business = "Heelyards"
    var id: String { rawValue }
}

struct HPTask: Identifiable, Codable {
    var id = UUID()
    var title: String
    var due: Date? = nil
    var bucket: HPBucket = .personal
    var done = false
    var created = Date()
}

struct HPMemo: Identifiable, Codable {
    var id = UUID()
    var title: String
    var body: String
    var created = Date()
}

struct HPSnapshot: Codable {
    var tasks: [HPTask] = []
    var memos: [HPMemo] = []
}

@MainActor
final class HPStore: ObservableObject {
    @Published var tasks: [HPTask] = [] { didSet { persist() } }
    @Published var memos: [HPMemo] = [] { didSet { persist() } }
    private let storageKey = "HeelPalm.snapshot.v1"

    init() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let snapshot = try? JSONDecoder().decode(HPSnapshot.self, from: data) else { return }
        tasks = snapshot.tasks
        memos = snapshot.memos
    }

    func addTask(_ title: String, due: Date? = nil, bucket: HPBucket = .personal) {
        let cleaned = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return }
        tasks.insert(HPTask(title: cleaned, due: due, bucket: bucket), at: 0)
    }

    func addMemo(_ title: String, body: String) {
        let cleaned = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return }
        memos.insert(HPMemo(title: cleaned, body: body), at: 0)
    }

    func toggle(_ task: HPTask) {
        guard let i = tasks.firstIndex(where: { $0.id == task.id }) else { return }
        tasks[i].done.toggle()
    }

    func delete(_ task: HPTask) { tasks.removeAll { $0.id == task.id } }
    func deleteMemo(_ memo: HPMemo) { memos.removeAll { $0.id == memo.id } }

    // Restore a browser backup after the user confirms replacing native local entries.
    func restore(_ imported: HPWebImport) {
        tasks = imported.tasks
        memos = imported.memos
    }

    func exportData() throws -> Data {
        try JSONEncoder().encode(HPSnapshot(tasks: tasks, memos: memos))
    }


    private func persist() {
        guard let encoded = try? JSONEncoder().encode(HPSnapshot(tasks: tasks, memos: memos)) else { return }
        UserDefaults.standard.set(encoded, forKey: storageKey)
    }
}
