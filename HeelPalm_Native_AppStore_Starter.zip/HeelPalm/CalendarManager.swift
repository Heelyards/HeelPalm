import EventKit
import Foundation

struct HPEvent: Identifiable {
    let id: String
    let title: String
    let start: Date
    let end: Date
    let calendar: String
    let source: String
    let colorHex: String
    let allDay: Bool
}

@MainActor
final class HPCalendarManager: ObservableObject {
    private let store = EKEventStore()
    @Published var events: [HPEvent] = []
    @Published var authorized = EKEventStore.authorizationStatus(for: .event) == .fullAccess
    @Published var message: String? = nil
    @Published var enabledCalendarIDs: Set<String> = []
    @Published var availableCalendars: [(id: String, title: String, source: String)] = []

    init() {
        NotificationCenter.default.addObserver(forName: .EKEventStoreChanged, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.reload() }
        }
        if authorized { reload() }
    }

    func requestAccess() async {
        do {
            authorized = try await store.requestFullAccessToEvents()
            if authorized { reload() } else { message = "Calendar access was not granted. You can enable it in iPhone Settings." }
        } catch {
            message = "Calendar permission error: \(error.localizedDescription)"
        }
    }

    func reload() {
        authorized = EKEventStore.authorizationStatus(for: .event) == .fullAccess
        guard authorized else { events = []; return }
        let calendars = store.calendars(for: .event)
        availableCalendars = calendars.map { ($0.calendarIdentifier, $0.title, $0.source.title) }
        let defaultsKey = "HeelPalm.enabledCalendars.v1"
        if let saved = UserDefaults.standard.stringArray(forKey: defaultsKey) {
            enabledCalendarIDs = Set(saved)
        } else {
            enabledCalendarIDs = Set(calendars.map(\.calendarIdentifier))
        }
        let visible = calendars.filter { enabledCalendarIDs.contains($0.calendarIdentifier) }
        let start = Calendar.current.date(byAdding: .month, value: -2, to: Date()) ?? Date()
        let end = Calendar.current.date(byAdding: .month, value: 12, to: Date()) ?? Date()
        guard !visible.isEmpty else { events = []; return }
        let predicate = store.predicateForEvents(withStart: start, end: end, calendars: visible)
        events = store.events(matching: predicate).map { e in
            let color = e.calendar.cgColor.components ?? [0.25, 0.55, 0.85, 1]
            let rgb: [CGFloat] = color.count >= 3 ? Array(color.prefix(3)) : [0.25, 0.55, 0.85]
            let hex = String(format: "#%02X%02X%02X", Int(rgb[0] * 255), Int(rgb[1] * 255), Int(rgb[2] * 255))
            return HPEvent(id: e.eventIdentifier ?? UUID().uuidString, title: e.title ?? "Untitled", start: e.startDate, end: e.endDate, calendar: e.calendar.title, source: e.calendar.source.title, colorHex: hex, allDay: e.isAllDay)
        }.sorted { $0.start < $1.start }
    }

    func toggleCalendar(_ id: String) {
        if enabledCalendarIDs.contains(id) { enabledCalendarIDs.remove(id) }
        else { enabledCalendarIDs.insert(id) }
        UserDefaults.standard.set(Array(enabledCalendarIDs), forKey: "HeelPalm.enabledCalendars.v1")
        reload()
    }

    func events(on date: Date) -> [HPEvent] {
        events.filter { Calendar.current.isDate($0.start, inSameDayAs: date) || ($0.start < date && $0.end > Calendar.current.startOfDay(for: date)) }
    }
}
