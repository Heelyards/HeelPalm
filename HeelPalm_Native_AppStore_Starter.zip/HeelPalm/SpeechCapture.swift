import AVFoundation
import Speech
import Foundation

@MainActor
final class HPSpeechCapture: ObservableObject {
    @Published var transcript = ""
    @Published var listening = false
    @Published var errorMessage: String? = nil
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?

    func start() async {
        guard !listening else { return }
        let speechAllowed = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
        guard speechAllowed else { errorMessage = "Enable Speech Recognition for HeelPalm in Settings."; return }
        let micAllowed = await AVAudioApplication.requestRecordPermission()
        guard micAllowed else { errorMessage = "Enable microphone access for HeelPalm in Settings."; return }
        guard recognizer?.isAvailable == true else { errorMessage = "Speech recognition is unavailable. Use the iPhone keyboard microphone instead."; return }
        transcript = ""
        errorMessage = nil
        request = SFSpeechAudioBufferRecognitionRequest()
        request?.shouldReportPartialResults = true
        let input = engine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.request?.append(buffer)
        }
        engine.prepare()
        do { try engine.start() }
        catch { errorMessage = "Could not start microphone: \(error.localizedDescription)"; stop(); return }
        listening = true
        task = recognizer?.recognitionTask(with: request!) { [weak self] result, error in
            Task { @MainActor in
                if let result { self?.transcript = result.bestTranscription.formattedString }
                if error != nil { self?.stop() }
            }
        }
    }

    func stop() {
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        task = nil
        request = nil
        listening = false
    }
}
