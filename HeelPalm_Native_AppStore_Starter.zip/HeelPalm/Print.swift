import Foundation
import UIKit

@MainActor
enum HPPrinter {
    static func printTasks(_ tasks: [HPTask]) {
        let rows = tasks.map { t in
            "<tr><td class='check'>☐</td><td>\(escape(t.title))</td><td>\(escape(t.bucket.rawValue))</td><td>\(t.due?.formatted(date: .abbreviated, time: .omitted) ?? "")</td></tr>"
        }.joined()
        perform("HeelPalm To-Do List", "<h1>TO-DO LIST</h1><table><thead><tr><th></th><th>Task</th><th>List</th><th>Due</th></tr></thead><tbody>\(rows)</tbody></table>")
    }

    static func printDay(_ day: Date, events: [HPEvent], tasks: [HPTask]) {
        let appointments = events.map { e in
            "<tr><td>\(e.allDay ? "All day" : e.start.formatted(date: .omitted, time: .shortened))</td><td>\(escape(e.title))</td><td>\(escape(e.calendar))</td></tr>"
        }.joined()
        let due = tasks.filter { !$0.done && ($0.due == nil || Calendar.current.startOfDay(for: $0.due!) <= Calendar.current.startOfDay(for: day)) }
        let tasksHTML = due.map { "<tr><td class='check'>☐</td><td>\(escape($0.title))</td><td>\(escape($0.bucket.rawValue))</td></tr>" }.joined()
        perform("HeelPalm Daily Agenda", "<h1>\(escape(day.formatted(date: .complete, time: .omitted)))</h1><h2>APPOINTMENTS</h2><table>\(appointments)</table><h2>TO-DO LIST</h2><table>\(tasksHTML)</table>")
    }

    private static func perform(_ title: String, _ body: String) {
        let html = """
        <html><head><meta name='viewport' content='width=device-width'><style>
        body{font-family:-apple-system,Helvetica,Arial,sans-serif;color:#17212b;padding:22px}
        h1{font-size:24px;border-bottom:3px solid #38a9e6;padding-bottom:8px}
        h2{font-size:14px;letter-spacing:1.5px;margin-top:26px} table{width:100%;border-collapse:collapse}
        td,th{text-align:left;border-bottom:1px solid #d7dce0;padding:10px 5px;font-size:12px}
        .check{font-size:23px;width:30px} th{color:#555}
        </style></head><body>\(body)<p style='margin-top:35px;color:#777;font-size:10px'>Printed with HeelPalm 🌴</p></body></html>
        """
        let printer = UIPrintInteractionController.shared
        printer.printInfo = UIPrintInfo(dictionary: nil)
        printer.printInfo?.jobName = title
        printer.printFormatter = UIMarkupTextPrintFormatter(markupText: html)
        printer.present(animated: true, completionHandler: nil)
    }

    private static func escape(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
         .replacingOccurrences(of: "<", with: "&lt;")
         .replacingOccurrences(of: ">", with: "&gt;")
         .replacingOccurrences(of: "\"", with: "&quot;")
    }
}
