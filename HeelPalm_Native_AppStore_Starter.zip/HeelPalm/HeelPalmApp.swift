import SwiftUI

@main
struct HeelPalmApp: App {
    @StateObject private var store = HPStore()
    @StateObject private var calendars = HPCalendarManager()

    var body: some Scene {
        WindowGroup {
            HPMainView()
                .environmentObject(store)
                .environmentObject(calendars)
                .tint(Color(red: 0.12, green: 0.57, blue: 0.84))
        }
    }
}
